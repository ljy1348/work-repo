// 1110
// let input = prompt("");
// document.querySelector("#texta").innerHTML = input;

// 1111
// let input = prompt("");
// document.querySelector("#texta").innerHTML = input+"%";

// 1112
// let input = prompt("");
// let input2 = prompt("");
// document.querySelector("#texta").innerHTML = input+" "+input2;

// 1113
// let input = prompt("");
// let input2 = prompt("");
// document.querySelector("#texta").innerHTML = input2+" "+input;

// 1114
// let input = Number(prompt(""));
// let input2 = Number(prompt(""));
// document.querySelector("#texta").innerHTML = input+input2;

// 1115
// let input = Number(prompt(""));
// let input2 = Number(prompt(""));
// document.querySelector("#texta").innerHTML = input+input2;

// 1116
// let input = Number(prompt(""));
// let input2 = Number(prompt(""));
// document.querySelector("#texta").innerHTML = input+"+"+input2+":"+(input+input2)+"\n";
// document.querySelector("#texta").innerHTML += input+"-"+input2+":"+(input-input2)+"\n";
// document.querySelector("#texta").innerHTML += input+"*"+input2+":"+(input*input2)+"\n";
// document.querySelector("#texta").innerHTML += input+"/"+input2+":"+(input/input2).toFixed(0)+"\n";

// 1117
// let input = Number(prompt(""));
// let input2 = Number(prompt(""));
// document.querySelector("#texta").innerHTML = (input*input2).toFixed(2);


// 1118
// let input = Number(prompt("밑변"));
// let input2 = Number(prompt("높이"));
// document.querySelector("#texta").innerHTML = (input*input2/2).toFixed(1);

// 1119
// let input = Number(prompt(""));
// document.querySelector("#texta").innerHTML = (input*24);

// 1120
// let input = Number(prompt(""));
// let input2 = Number(prompt(""));
// let input3 = Number(prompt(""));
// document.querySelector("#texta").innerHTML = ((input+input2+input3)/3).toFixed(2);

// 1121
// let input = Number(prompt(""));
// let input2 = Number(prompt(""));
// document.querySelector("#texta").innerHTML = (input%input2);

// 1122
// let input = Number(prompt(""));
// let result = Math.floor((input/60))+" "+(input%60).toFixed(0);
// document.querySelector("#texta").innerHTML = (result);

//1123
// let input = Number(prompt(""));
// let result = (9/5*input)+32;
// document.querySelector("#texta").innerHTML = (result.toFixed(3));

// 1124
// let input = Number(prompt(""));
// let result = input.toString(16);
// let result2 = input.toString(8);
// document.querySelector("#texta").innerHTML = result2+" "+result.toUpperCase();

// 1131
// let input = prompt("");
// document.querySelector("#texta").innerHTML = input;

// 1132
// let input = prompt("");
// document.querySelector("#texta").innerHTML = input;

// 1133
// let input = prompt("");
// document.querySelector("#texta").innerHTML = input;

// 1135
// let input = prompt("");

// let result = input.split(" ");

// if (result[0] >= result[1]) {
//     document.querySelector("#texta").innerHTML = 1;
// } else {
//     document.querySelector("#texta").innerHTML = 0;
// }

// 1136
// let input = prompt("");

// let result = input.split(" ");

// if (result[0] === result[1]) {
//     document.querySelector("#texta").innerHTML = 1;
// } else {
//     document.querySelector("#texta").innerHTML = 0;
// }

// 1137
// let input = prompt("");

// let result = input.split(" ");

// if (result[0] != result[1]) {
//     document.querySelector("#texta").innerHTML = 1;
// } else {
//     document.querySelector("#texta").innerHTML = 0;
// }

// 1138
// let input = Number(prompt(""));

// document.querySelector("#texta").innerHTML = Number(!Boolean(input));

// 1139
// let input = Boolean(Number(prompt("")));
// let input2 = Boolean(Number(prompt("")));

// document.querySelector("#texta").innerHTML =Number(input && input2);

// 1140
// let input = Boolean(Number(prompt("")));
// let input2 = Boolean(Number(prompt("")));

// document.querySelector("#texta").innerHTML =Number(input || input2);

// 1143
// let input = Number(prompt(""));
// let input2 = Number(prompt(""));
// let result = input.toString(2);
// let result2 = input2.toString(2);
// document.querySelector("#texta").innerHTML = parseInt(result&result2, 2);

// 1144
// let input = Number(prompt(""));
// let input2 = Number(prompt(""));
// let result = input.toString(2);
// let result2 = input2.toString(2);
// document.querySelector("#texta").innerHTML = parseInt(result|result2, 2);

// 1147
// let input = Number(prompt(""));
// let input2 = Number(prompt(""));
// document.querySelector("#texta").innerHTML = (input<<input2);

// 1148
// let input = Number(prompt(""));
// let input2 = Number(prompt(""));
// document.querySelector("#texta").innerHTML = (input>>input2);

// 1149
// let input = Number(prompt(""));
// let input2 = Number(prompt(""));
// let max = Math.max(input, input2);

// document.querySelector("#texta").innerHTML = max;

// 1150
// let input = Number(prompt(""));
// let input2 = Number(prompt(""));
// let input3 = Number(prompt(""));
// let min = Math.min(input, input2, input3);

// document.querySelector("#texta").innerHTML = min;





